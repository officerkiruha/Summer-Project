const canvas = document.querySelector('canvas');
const c = canvas.getContext('2d');
canvas.width = 1024
canvas.height = 576
collisionsMap=[]
for(let i =0;i<collisions.length;i +=135){
collisionsMap.push(collisions.slice(i,i+135))
};

const collisionsBlocks = [];
collisionsMap.forEach((row,y) => {
   row.forEach((Symbol,x) =>{
      if(Symbol === 1){
         console.log('draw a block here')
         collisionsBlocks.push(new collisionsBlock({
            position:{
               x: x * 135,
               y: y * 135,
            }
         }))
      }
   })
   
});
console.log(collisionsBlocks)

console.log(collisionsMap)

const image = new Image()
image.src='Game_MAP.jpg'

/*image.onload = () => {
//   c.drawImage(image,0,-1100) 
   }*/
// ---------- פונקציית בדיקת התנגשות ----------
function rectsOverlap(a, b){
  return a.x < b.mapX + b.width &&
         a.x + a.width > b.mapX &&
         a.y < b.mapY + b.height &&
         a.y + a.height > b.mapY
}

// ---------- PLAYER ----------
const player = {
  x: 500,
  y: 0,
  width: 50,
  height: 50,
  color: 'black',
  lives: 3,
  invincible: false,
  iTimer: 0,
  iDuration: 1.0
}

// ---------- מחלקת Enemy ----------
class Enemy {
  constructor({ mapX, mapY, toX, speed, imageSrc }) {
    this.startX = mapX
    this.mapX = mapX
    this.mapY = mapY
    this.toX = toX
    this.speed = speed
    this.width = 60
    this.height = 40
    this.direction = 1
    this.image = new Image()
    this.image.src = imageSrc
    this.imageLoaded = false
    this.image.onload = () => { this.imageLoaded = true }
  }

  update() {
    this.mapX += this.speed * this.direction
    if (this.mapX <= this.startX) {
      this.mapX = this.startX
      this.direction = 1
    }
    if (this.mapX >= this.toX) {
      this.mapX = this.toX
      this.direction = -1
    }
  }

  draw(offset) {
    const screenX = this.mapX - offset.x
    const screenY = this.mapY - offset.y
    if (this.imageLoaded) {
      c.save()
      if (this.direction === 1) {
        c.translate(screenX + this.width, screenY)
        c.scale(-1, 1)
        c.drawImage(this.image, 0, 0, this.width, this.height)
      } else {
        c.drawImage(this.image, screenX, screenY, this.width, this.height)
      }
      c.restore()
    } else {
      c.fillStyle = 'red'
      c.fillRect(screenX, screenY, this.width, this.height)
    }
  }
}

// ---------- CREATE ENEMIES ----------
const enemies = [
  new Enemy({ mapX: 0, mapY: 0, toX:400, speed:1, imageSrc: 'TheMainDragon.png' }),
  new Enemy({ mapX: 100, mapY: 150, toX:300, speed:1, imageSrc: 'TheMainDragon.png' }),
  new Enemy({ mapX: 0, mapY: 425, toX:450, speed:1,imageSrc: 'TheMainDragon.png' }),
  new Enemy({ mapX: 0, mapY: 825, toX:600, speed:1,imageSrc: 'TheMainDragon.png' }),
  new Enemy({ mapX: 200, mapY: 1240, toX:800, speed:1,imageSrc: 'TheMainDragon.png' }),
  new Enemy({ mapX: 300, mapY: 1385, toX:800, speed:1, imageSrc: 'TheMainDragon.png' }),
  new Enemy({ mapX: 900, mapY: 1450, toX:1050, speed:1,imageSrc: 'TheMainDragon.png' }),
  new Enemy({ mapX: 1050, mapY: 1200, toX:1500, speed:1,imageSrc: 'TheMainDragon.png' }),
  new Enemy({ mapX: 1200, mapY: 1450, toX:1400, speed:1,imageSrc: 'TheMainDragon.png' }),
  new Enemy({ mapX: 1055, mapY: 1015, toX:1350, speed:1, imageSrc: 'TheMainDragon.png' }),
  new Enemy({ mapX: 500, mapY: 1100, toX:1100, speed:1, imageSrc: 'TheMainDragon.png' }),
  new Enemy({ mapX: 0, mapY: 980, toX:650, speed:1,imageSrc: 'TheMainDragon.png' }),
  new Enemy({ mapX:600, mapY: 875, toX:1400, speed:1, imageSrc: 'TheMainDragon.png' }),
  new Enemy({ mapX:1000, mapY: 750, toX:1400, speed:1, imageSrc: 'TheMainDragon.png' }),
  new Enemy({ mapX:625, mapY: 750, toX:950, speed:1, imageSrc: 'TheMainDragon.png' }),
  new Enemy({ mapX:0, mapY: 680, toX:400, speed:1, imageSrc: 'TheMainDragon.png' }),
  new Enemy({ mapX:500, mapY: 680, toX:800, speed:1, imageSrc: 'TheMainDragon.png' }),
  new Enemy({ mapX:0, mapY: 530, toX:500, speed:1, imageSrc: 'TheMainDragon.png' }),
  new Enemy({ mapX:600, mapY: 550, toX:850, speed:1, imageSrc: 'TheMainDragon.png' }),
  new Enemy({ mapX:1100, mapY: 550, toX:1450, speed:1, imageSrc: 'TheMainDragon.png' }),
  new Enemy({ mapX:900, mapY: 450, toX:1100, speed:1, imageSrc: 'TheMainDragon.png' }),
  new Enemy({ mapX:500, mapY: 445, toX:800, speed:1, imageSrc: 'TheMainDragon.png' }),
  new Enemy({ mapX:600, mapY: 300, toX:1350, speed:1, imageSrc: 'TheMainDragon.png' }),
  new Enemy({ mapX:200, mapY: 300, toX:500, speed:1, imageSrc: 'TheMainDragon.png' }),
  new Enemy({ mapX:500, mapY: 140, toX:950, speed:1, imageSrc: 'TheMainDragon.png' }),
  new Enemy({ mapX:1200, mapY: 140, toX:1400, speed:1, imageSrc: 'TheMainDragon.png' }),
  new Enemy({ mapX:500, mapY: 25, toX:1000, speed:1, imageSrc: 'TheMainDragon.png' }),
]

// ---------- CAMERA ----------
const camera = { offset: { x:500, y:0 } }

// ---------- UPDATE PLAYER ----------
function updatePlayer(dt){
  if(player.invincible){
    player.iTimer -= dt
    if(player.iTimer <= 0) player.invincible = false
  }

  enemies.forEach(enemy => {
    if(!player.invincible && rectsOverlap(player, enemy)){
      player.lives -= 1
      player.invincible = true
      player.iTimer = player.iDuration
      player.x -= 20
    }
  })
}

// ---------- DRAW PLAYER ----------
function drawHeart(x, y, color) {
  c.fillStyle = color
  c.beginPath()
  c.moveTo(x, y + 6)
  c.bezierCurveTo(x - 12, y - 10, x - 15, y + 10, x, y + 20)
  c.bezierCurveTo(x + 15, y + 10, x + 12, y - 10, x, y + 6)
  c.closePath()
  c.fill()
}

function drawPlayer(){
  if(!player.invincible || Math.floor(performance.now()/100) % 2 === 0){
    c.fillStyle = player.color
    c.fillRect(player.x - camera.offset.x, player.y - camera.offset.y, player.width, player.height)
  }

  for (let i = 0; i < 3; i++) {
    const color = i < player.lives ? 'red' : 'gray'
    drawHeart(30 + i * 35, 30, color)
  }

  c.fillStyle = 'white'
  c.font = '24px sans-serif'
  if(player.lives <= 0){
    c.fillText('GAME OVER', canvas.width/2 - 60, canvas.height/2)
  }
}

// ---------- ANIMATE ----------
let lastTime = 0
function animate(time){
  const dt = (time - lastTime)/1000
  lastTime = time

  requestAnimationFrame(animate)
  c.clearRect(0,0,canvas.width,canvas.height)

  // מצייר את המפה
  c.drawImage(image, -camera.offset.x, -camera.offset.y)

  // עדכון ואיור אויבים
  enemies.forEach(enemy => {
    enemy.update()
    enemy.draw(camera.offset)
  })

  // עדכון שחקן
  updatePlayer(dt)

  // עדכון ואיור מפתחות
  updateKeys()                       // בודק איסוף מפתחות
  keys.forEach(key => key.draw(camera.offset))  // מצייר מפתחות במפה
  drawKeysUI()                        // מצייר את הממשק (אייקון + ספירה)

  // ציור השחקן
  drawPlayer()
}

image.onload = () => {
  animate(0)
}


// ---------- מחלקת מפתח ----------
class Key {
  constructor({ mapX, mapY, imageSrc }) {
    this.mapX = mapX
    this.mapY = mapY
    this.width = 40
    this.height = 40
    this.collected = false

    this.image = new Image()
    this.image.src = imageSrc
    this.imageLoaded = false
    this.image.onload = () => { this.imageLoaded = true }
  }

  draw(offset) {
    if (this.collected) return
    const screenX = this.mapX - offset.x
    const screenY = this.mapY - offset.y
    if (this.imageLoaded) {
      c.drawImage(this.image, screenX, screenY, this.width, this.height)
    } else {
      c.fillStyle = 'yellow'
      c.fillRect(screenX, screenY, this.width, this.height)
    }
  }
}

// ---------- יצירת מפתחות ----------
const keys = [
  new Key({ mapX: 0, mapY: 25, imageSrc: 'Key.png' }),
  new Key({ mapX: 1560, mapY: 530, imageSrc: 'Key.png' }),
  new Key({ mapX: 1200, mapY: 1540, imageSrc: 'Key.png' }),
  new Key({ mapX: 0, mapY: 1350, imageSrc: 'Key.png' }),
]

let keysCollected = 0
const totalKeys = keys.length

// ---------- טוענים את אייקון המפתח לממשק פעם אחת ----------
const keyIcon = new Image()
keyIcon.src = 'Key.png'
let keyIconLoaded = false
keyIcon.onload = () => { keyIconLoaded = true }

// ---------- בדיקת איסוף מפתח ----------
function updateKeys() {
  keys.forEach(key => {
    if (!key.collected && rectsOverlap(player, key)) {
      key.collected = true
      keysCollected++
    }
  })
}

// ---------- ציור מפתח + כמות למעלה במסך ----------
function drawKeysUI() {
  const iconSize = 32
  const margin = 20
  const x = canvas.width - iconSize - margin
  const y = margin

  // מצייר את האייקון של המפתח רק אם נטען
  if (keyIconLoaded) {
    c.drawImage(keyIcon, x, y, iconSize, iconSize)
  } else {
    c.fillStyle = 'yellow'
    c.fillRect(x, y, iconSize, iconSize)
  }

  // מצייר את הטקסט ליד האייקון
  c.fillStyle = 'white'
  c.font = '24px sans-serif'
  c.fillText(`${keysCollected}/${totalKeys}`, x - 50, y + 24)
}





/*const monsters = [
   new Monster({
      x: 0,
      y: 0,
      size : 15,
      imageSrc: 'DragonBot.png'
   }),
];



for(let i = monsters.length-1;i >=0;i--){
   const monster = monsters[i];
   monster.update(collisionsBlocks);
   monster.draw();
}*/





//עד 1:23:44
//מפה צריך לייצר גם בשאר הקוד כמו ANIMETION




/*for(let i = 0; i < collisions.length;i+=135){
   collisionsMap.push(collisions.slice(i,135+i));
}
class Boundary{
   static width = 48
   static height = 48 

   constructor({position}){
      this.position = position
      this.width = 48
      this.height = 48
   }
   
   draw() {
          c.fillStyle='red';
          c.fillRect(this.position.x,this.position.y,this.width,this.height)
   }
};

const boundaries = [];
collisionsMap.ForEach((row,i)=> {
   row.ForEach((Symbol,j) => {
      if(Symbol===1025 )
      boundaries.push(
         new Boundary({
            position:{
               x: j * Boundary.width,
               y: i * Boundary.height
            }
         })
      )
   })
})*/

/*const image = new Image()
image.src='Game_MAP.jpg'*/

/*const PlayerImage = new Image();
PlayerImage.src='Wallforblock.png';*/

/*image.onload = () => {
   c.drawImage(image,0,-1100) 
 /*  c.drawImage(
      PlayerImage,
      //0,
      //0,
      //0,
      //0,
      0,140
   );}*/ 

