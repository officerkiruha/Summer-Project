function GameMusic() {
  const audio = document.getElementById("GameMusic");
  window.addEventListener("click", () => {
    audio.muted = false;
    audio.play();
  }, { once: true });
}

GameMusic();