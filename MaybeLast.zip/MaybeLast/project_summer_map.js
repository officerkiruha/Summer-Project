const canvas = document.querySelector('canvas');
const c = canvas.getContext('2d');

const gravity = 0.5;

canvas.width = 1620;
canvas.height = 1620;

const startx = canvas.width / 2;
const starty = canvas.height / 2;
const playerSpeed = canvas.width * 0.003;

// ---------- BACKGROUND ----------
const backgroundIMG = new Image();
backgroundIMG.src = './images/Game_MAP.jpg';

function backgroundCanvas() {
  c.drawImage(backgroundIMG, 0, 0, canvas.width, canvas.height);
}

// ---------- PLAYER CLASS ----------
class Player {
  constructor(collisionsBlocks) {
    this.height = 30;
    this.width = 30;
    this.position = { x: 30, y: starty - this.height / 2 + 200 };
    this.velocity = { x: 0, y: 1 };
    this.collisionsBlocks = collisionsBlocks;
    this.cameraBox = { position: { x: this.position.x, y: this.position.y }, width: 256, height: 80 };
    
    this.image = new Image();
    const selectedPlayer = localStorage.getItem("selectedPlayer");
    const images_spirt = [
      "images/eli_spirt_end.png",
      "images/elishive_spirt_end1.png",
      "images/spirt_hazout.png",
      "images/kirl_spirt_end.png",
      "images/shay_spirt_end.png"
    ];
    this.image.src = images_spirt[parseInt(selectedPlayer) - 1];

    this.frameX = 0;
    this.frameY = 0;
    this.onGround = false;
    this.direction = "left";
    this.frameCounter = 0;

    // חדש: חיים ואי-פגיעות
    this.lives = 3;
    this.invincible = false;
    this.iTimer = 0;
    this.iDuration = 1.0;
  }

  make() {
    if (!this.onGround) { this.frameX = 1; this.frameY = 0; }
    else if (this.velocity.x !== 0) {
      this.frameY = 0;
      this.frameCounter++;
      if (this.frameCounter % 15 === 0) this.frameX = (this.frameX + 1) % 2;
    } else { this.frameX = 0; this.frameY = 0; }

    c.save();
    const spriteWidth = 64;
    const spriteHeight = 64;

    if (this.direction === "right") {
      c.scale(-1, 1);
      c.drawImage(this.image, this.frameX * spriteWidth, this.frameY * spriteHeight, spriteWidth, spriteHeight,
                  -this.position.x - this.width, this.position.y, this.width, this.height);
    } else {
      c.drawImage(this.image, this.frameX * spriteWidth, this.frameY * spriteHeight, spriteWidth, spriteHeight,
                  this.position.x, this.position.y, this.width, this.height);
    }
    c.restore();
  }

  cameraToLeft({ canvas, camera }) {
    this.refreshCameraBox();
    const cameraBoxRight = this.cameraBox.position.x + this.cameraBox.width;
    const scaledCanvas = camera.position.x + (canvas.width / 2) - 100;
    if (cameraBoxRight >= scaledCanvas) camera.position.x += this.velocity.x;
  }

  cameraToRight({ canvas, camera }) {
    this.refreshCameraBox();
    const cameraBoxLeft = this.cameraBox.position.x;
    const leftBoundary = camera.position.x + canvas.width * 0.2;
    if (cameraBoxLeft < leftBoundary) {
      camera.position.x += this.velocity.x;
      if (camera.position.x < 0) camera.position.x = 0;
    }
  }

  cameraPanUp({ canvas, camera }) {
    this.refreshCameraBox();
    const cameraBoxTop = this.cameraBox.position.y;
    const topBoundary = camera.position.y + canvas.height * 0.25;
    if (cameraBoxTop < topBoundary) camera.position.y += this.velocity.y !== 0 ? this.velocity.y : -2;
    if (camera.position.y < 0) camera.position.y = 0;
  }

  cameraPanDown({ canvas, camera }) {
    this.refreshCameraBox();
    const cameraBoxBottom = this.cameraBox.position.y + this.cameraBox.height;
    const bottomBoundary = camera.position.y + (canvas.height / 2) * 0.75;
    const worldHeight = canvas.height * 2;
    if (cameraBoxBottom > bottomBoundary) {
      camera.position.y += Math.abs(this.velocity.y) || 2;
      if (camera.position.y + canvas.height > worldHeight) camera.position.y = worldHeight - canvas.height;
    }
  }

  refreshCameraBox() {
    this.cameraBox = { position: { x: this.position.x - 115, y: this.position.y - 20 }, width: 256, height: 80 };
  }

  refresh() {
    this.make();
    this.refreshCameraBox();
    this.position.x += this.velocity.x;
    this.checkForHorizontalPosition();
    this.applyGravity();
    this.checkForVerticalPosition();
  }

  applyGravity() {
    this.position.y += this.velocity.y;
    this.velocity.y += gravity;
  }

  checkForVerticalPosition() {
    for (let i = 0; i < this.collisionsBlocks.length; i++) {
      const block = this.collisionsBlocks[i];
      if (collisionDetection({ player: this, block })) {
        if (this.velocity.y > 0) { this.velocity.y = 0; this.position.y = block.position.y - this.height - 0.01; break; }
        if (this.velocity.y < 0) { this.velocity.y = 0; this.position.y = block.position.y + block.height + 0.01; break; }
      }
    }
  }

  checkForHorizontalPosition() {
    for (let i = 0; i < this.collisionsBlocks.length; i++) {
      const block = this.collisionsBlocks[i];
      if (collisionDetection({ player: this, block })) {
        if (this.velocity.x > 0) { this.velocity.x = 0; this.position.x = block.position.x - this.width - 0.01; break; }
        if (this.velocity.x < 0) { this.velocity.x = 0; this.position.x = block.position.x + block.width + 0.01; break; }
      }
    }
  }
}

// ---------- COLLISIONS BLOCKS ----------
//const collisionsBlocks = []; // כאן תמלא בהתאם למפה שלך (כמו בקוד 2)

// ---------- PLAYER INSTANCE ----------
const player = new Player(collisionsBlocks);

// ---------- CAMERA ----------
const camera = { position: { x: 0, y: 360 } };

// ---------- KEYBOARD ----------
const keys = { d: { preesed: false }, a: { preesed: false } };

// ---------- ENEMIES ----------
class Enemy {
  constructor({ mapX, mapY, toX, speed, imageSrc }) {
    this.startX = mapX;
    this.mapX = mapX;
    this.mapY = mapY;
    this.toX = toX;
    this.speed = speed;
    this.width = 60;
    this.height = 40;
    this.direction = 1;
    this.image = new Image();
    this.image.src = imageSrc;
    this.imageLoaded = false;
    this.image.onload = () => { this.imageLoaded = true; };
  }

  update() {
    this.mapX += this.speed * this.direction;
    if (this.mapX <= this.startX) { this.mapX = this.startX; this.direction = 1; }
    if (this.mapX >= this.toX) { this.mapX = this.toX; this.direction = -1; }
  }

  draw(offset) {
    const screenX = this.mapX - offset.x;
    const screenY = this.mapY - offset.y;
    if (this.imageLoaded) {
      c.save();
      if (this.direction === 1) { c.translate(screenX + this.width, screenY); c.scale(-1,1); c.drawImage(this.image,0,0,this.width,this.height);}
      else { c.drawImage(this.image, screenX, screenY, this.width, this.height);}
      c.restore();
    } else { c.fillStyle='red'; c.fillRect(screenX, screenY,this.width,this.height);}
  }
}

const enemies = [
  new Enemy({ mapX: 0, mapY: 0, toX:400, speed:1, imageSrc: 'TheMainDragon.png' }),
  new Enemy({ mapX: 100, mapY: 150, toX:300, speed:1, imageSrc: 'TheMainDragon.png' }),
  new Enemy({ mapX: 0, mapY: 425, toX:450, speed:1,imageSrc: 'TheMainDragon.png' }),
];

// ---------- KEYS ----------
class Key {
  constructor({ mapX,mapY,imageSrc }) {
    this.mapX = mapX; this.mapY = mapY;
    this.width = 40; this.height = 40;
    this.collected = false;
    this.image = new Image(); this.image.src = imageSrc;
    this.imageLoaded=false; this.image.onload=()=>{this.imageLoaded=true;}
  }
  draw(offset) {
    if(this.collected) return;
    const screenX=this.mapX - offset.x;
    const screenY=this.mapY - offset.y;
    if(this.imageLoaded) c.drawImage(this.image,screenX,screenY,this.width,this.height);
    else { c.fillStyle='yellow'; c.fillRect(screenX,screenY,this.width,this.height);}
  }
}

const keysObjects = [
  new Key({ mapX:0,mapY:25,imageSrc:'Key.png'}),
  new Key({ mapX:1560,mapY:530,imageSrc:'Key.png'}),
  // הוסף את כל המפתחות שלך כפי שהגדרת בקוד 2
];

let keysCollected = 0;
const totalKeys = keysObjects.length;

const keyIcon = new Image();
keyIcon.src = 'Key.png';
let keyIconLoaded=false;
keyIcon.onload=()=>{keyIconLoaded=true;}

// ---------- WIN POSITION ----------
class TheWinPos {
  constructor({ mapX,mapY,imageSrc }) {
    this.mapX=mapX; this.mapY=mapY;
    this.width=100; this.height=60;
    this.image=new Image(); this.image.src=imageSrc;
    this.imageLoaded=false; this.image.onload=()=>{this.imageLoaded=true;}
  }
  draw(offset){
    const screenX=this.mapX-offset.x;
    const screenY=this.mapY-offset.y;
    if(this.imageLoaded) c.drawImage(this.image,screenX,screenY,this.width,this.height);
    else { c.fillStyle='blue'; c.fillRect(screenX,screenY,this.width,this.height);}
  }
}

const FinalPos = new TheWinPos({ mapX:1400,mapY:9,imageSrc:'TheFinalPoint.png' });

// ---------- UTILS ----------
function rectsOverlap(a,b){ return a.x < b.mapX+b.width && a.x+a.width>b.mapX && a.y < b.mapY+b.height && a.y+a.height>b.mapY; }
function updateKeys() {
  keysObjects.forEach(key=>{
    const playerRect={x:player.position.x,y:player.position.y,width:player.width,height:player.height};
    if(!key.collected && rectsOverlap(playerRect,key)){ key.collected=true; keysCollected++; }
  })
}

// ---------- DRAW KEYS UI ----------
function drawKeysUI(){
  const iconSize=32,margin=20,x=canvas.width-iconSize-margin,y=margin;
  if(keyIconLoaded) c.drawImage(keyIcon,x,y,iconSize,iconSize); else c.fillStyle='yellow'; c.fillRect(x,y,iconSize,iconSize);
  c.fillStyle='white'; c.font='24px sans-serif';
  c.fillText(`${keysCollected}/${totalKeys}`,x-50,y+24);
}

// ---------- DRAW HEART ----------
function drawHeart(x,y,color){ c.fillStyle=color;c.beginPath();c.moveTo(x,y+6);c.bezierCurveTo(x-12,y-10,x-15,y+10,x,y+20);c.bezierCurveTo(x+15,y+10,x+12,y-10,x,y+6);c.closePath();c.fill();}

// ---------- UPDATE PLAYER LIVES ----------
function updatePlayerLives(dt){
  if(player.invincible){ player.iTimer-=dt; if(player.iTimer<=0) player.invincible=false; }
  enemies.forEach(enemy=>{
    if(!player.invincible && rectsOverlap({x:player.position.x,y:player.position.y,width:player.width,height:player.height},enemy)){
      player.lives--; player.invincible=true; player.iTimer=player.iDuration;
      player.position.x -= 20;
    }
  });
}

// ---------- MAIN LOOP ----------
function loop(){
  requestAnimationFrame(loop);

  player.velocity.x = 0;
  if(keys.d.preesed){ player.velocity.x=playerSpeed; player.cameraToLeft({canvas,camera}); }
  if(keys.a.preesed){ player.velocity.x=-playerSpeed; player.cameraToRight({canvas,camera}); }
  if(player.velocity.y<0) player.cameraPanUp({canvas,camera});
  if(player.velocity.y>0) player.cameraPanDown({canvas,camera});

  c.clearRect(0,0,canvas.width,canvas.height);
  c.save();
  c.scale(2,2);
  c.translate(-camera.position.x,-camera.position.y);

  backgroundCanvas();
  enemies.forEach(enemy=>{enemy.update();enemy.draw(camera.position);});
  updateKeys();
  keysObjects.forEach(key=>key.draw(camera.position));
  FinalPos.draw(camera.position);
  updatePlayerLives(0.016); // dt מצוין באופן קבוע כאן, אפשר לשפר

  player.refresh();
  c.restore();

  drawKeysUI();
  for(let i=0;i<3;i++){ const color=i<player.lives?'red':'gray'; drawHeart(30+i*35,30,color);}
  if(player.lives<=0){ c.fillStyle='white'; c.font='48px sans-serif'; c.fillText('GAME OVER',canvas.width/2-100,canvas.height/2);}
}

loop();

// ---------- KEYBOARD EVENTS ----------
window.addEventListener("keydown",(event)=>{
  switch(event.key){
    case 'd':
       keys.d.preesed=true;
     player.direction='left';
      break;
    case 'a':
       keys.a.preesed=true;
       player.direction='right'; 
       break;
    case 'w': 
    player.velocity.y=-12;
     break;
  }
})

window.addEventListener("keyup",(event)=>{
  switch(event.key){
    case 'd':
       keys.d.preesed=false; 
       break;
    case 'a':
       keys.a.preesed=false;
        break;
  }
})
